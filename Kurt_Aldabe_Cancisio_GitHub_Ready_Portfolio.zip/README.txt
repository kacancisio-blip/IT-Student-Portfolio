Kurt Aldabe Cancisio — IT Student Portfolio
Theme: Violet and Black

GitHub-ready structure:
- index.html
- css/style.css
- js/script.js
- assets/profile.jpg

Upload index.html and the css, js, and assets folders to the root of your GitHub repository. Keep folder names exactly as shown.

Publish with GitHub Pages:
1. Open your repository on GitHub.
2. Choose Add file → Upload files.
3. Upload all files and folders above, then commit.
4. Open Settings → Pages.
5. Under Build and deployment, choose Deploy from a branch.
6. Select the main branch and / (root), then Save.
